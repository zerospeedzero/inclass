<?php
    $host = "localhost";
    $username = "jmorin_user";
    $password = "Jigglypants1";
    $database = "jmorin_mmda225_inclass";
    $connect = mysqli_connect($host, $username, $password, $database);
?>